# node-red-contrib-weekSUN
<h3>Node app for buldind another node-red modules</h3>
<pre>
<a href="https://raw.githubusercontent.com/ZnakZorro/node-red-contrib-weekSUN/master/proto-red.js">https://raw.githubusercontent.com/ZnakZorro/node-red-contrib-weekSUN/master/proto-red.js</a>
</pre>
<pre>wget https://raw.githubusercontent.com/ZnakZorro/node-red-contrib-weekSUN/master/proto-red.js</pre>
<pre>node proto-red.js mynewmodule</pre>
<pre>
sudo cp proto-red.js /bin/red-prototype.js<br />
sudo chmod +x /bin/red-prototype.js<br />
red-prototype.js
</pre>

<hr />

<h2>Node-red for start building own module</h2>

<pre>
cd ~/.node-red

mkdir red

cd red
</pre>

<pre>

sudo git clone https://github.com/ZnakZorro/node-red-contrib-weekSUN.git

cd node-red-contrib-weekSUN

sudo chown pi:pi *

sudo npm link

cd ~/.node-red

sudo npm link node-red-contrib-weekSUN


</pre>
