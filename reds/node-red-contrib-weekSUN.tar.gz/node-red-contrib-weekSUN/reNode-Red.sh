
echo "------------------------"
ps -ef | grep "node /usr/local/lib/node_modules/node-red/red.js" | grep -v grep
echo "------------------------"
ps -ef | grep "node /usr/local/lib/node_modules/node-red/red.js" | grep -v grep | awk '{print "sudo kill -9 "$2}' | sh
/usr/local/bin/node /usr/local/lib/node_modules/node-red/red.js $1


#pm2 start $HOME/app/radio/index.js --watch
