
module.exports = function(RED) {
	"use strict";
    function weekSUNNode(config) {
        RED.nodes.createNode(this,config);
        this.name = config.name;
        this.summertime = config.summertime;
        this.delay = config.delay;         
        this.interval = config.interval;
        this.PWMstate = parseInt(config.PWMstate);
		
        var node = this;
        this.on('input', function(msg) {
		
	
	
	
		
				var weekSun = [
						["08:21", "15:49"],
						["08:17", "15:59"],
						["08:11", "16:10"],
						["08:03", "16:23"],
						["07:52", "16:36"],
						["07:39", "16:50"],
						["07:26", "17:04"],
						["07:11", "17:18"],
						["06:55", "17:31"],
						["06:39", "17:45"],
						["06:22", "17:58"],
						["06:05", "18:11"],
						["05:48", "18:24"],
						["05:31", "18:36"],
						["05:15", "18:49"],
						["04:59", "19:01"],
						["04:44", "19:14"],
						["04:29", "19:26"],
						["04:16", "19:39"],
						["04:04", "19:50"],
						["03:54", "20:01"],
						["03:46", "20:10"],
						["03:40", "20:18"],
						["03:37", "20:24"],
						["03:37", "20:27"],
						["03:39", "20:28"],
						["03:44", "20:26"],
						["03:51", "20:21"],
						["04:00", "20:14"],
						["04:10", "20:05"],
						["04:21", "19:53"],
						["04:32", "19:40"],
						["04:44", "19:26"],
						["04:56", "19:11"],
						["05:08", "18:55"],
						["05:20", "18:39"],
						["05:32", "18:22"],
						["05:45", "18:05"],
						["05:57", "17:48"],
						["06:09", "17:31"],
						["06:22", "17:14"],
						["06:35", "16:58"],
						["06:48", "16:42"],
						["07:01", "16:27"],
						["07:15", "16:14"],
						["07:28", "16:02"],
						["07:41", "15:52"],
						["07:53", "15:44"],
						["08:03", "15:39"],
						["08:12", "15:37"],
						["08:18", "15:37"],
						["08:21", "15:41"],
						["08:21", "15:48"]
				];
				
				function prepTI(sun){
					//console.log('node.summertime=',node.summertime);
					if (node.summertime){
						var arr0 = sun[0].split(':');
						var s0 = (('0'+String((parseInt(arr0[0])+1))).slice(-2))+":"+arr0[1];
						var arr1 = sun[1].split(':');
						var s1 = (('0'+String((parseInt(arr1[0])+1))).slice(-2))+":"+arr1[1];
						//console.log(sun,[s0,s1]);
						return [s0,s1];
					} else {
						return sun;
					}
				}

				function oneORzero(sun){
					console.log('??? delay=',node.delay); // todo delay in minutes
					var d = new Date();
					var h = d.getHours();
					var m = d.getMinutes();
					var nowMinuta = parseInt(m) + (60 * parseInt(h));
					var arr = sun[0].split(':');
					var riseMinuta = parseInt(arr[1]) + (60 * parseInt(arr[0]));
					var ars = sun[1].split(':');
					var ssetMinuta = parseInt(ars[1]) + (60 * parseInt(ars[0]));
					//var info= sun[0]+' '+sun[1]+' = '+h+':'+m+' nowMinuta='+nowMinuta+' riseMinuta='+riseMinuta+' ssetMinuta='+ssetMinuta;
					var out=0;
					if (nowMinuta > riseMinuta) out = 1;
					if (nowMinuta > ssetMinuta)  out = 0;
					return out;
				}

				Date.prototype.getWeek = function() {
					var dt = new Date(this.getFullYear(),0,1);
					return Math.ceil((((this - dt) / 86400000) + dt.getDay()+1)/7);
				};
				var now = (new Date()).toLocaleString();
				var myDate = new Date();
				var week = myDate.getWeek();
var SesonSun=prepTI(weekSun[week]);
//console.log(SesonSun,weekSun[week]);

				var dayState   = oneORzero(SesonSun);
				var nightState = (dayState ===1) ? 0:1;

				var msg1 = {payload:dayState}
				var msg2 = {payload:nightState}

				var msg3 = {payload:SesonSun[0]}
				var msg4 = {payload:SesonSun[1]}
				var msg5 = {payload:{"now":now, "week":week,"sunrise":SesonSun[0],"sunset":SesonSun[1]}};
				msg.payload=now+' \nweek: '+week+', \nSunRise: '+SesonSun[0]+', \nSunSet: '+SesonSun[1];
				
				var status = now+' = '+SesonSun[0]+' - '+SesonSun[1];
				this.status({fill:"yellow",shape:"dot",text:"Sun: "+status});
				
				node.send([msg1,msg2,msg3,msg4,msg5,msg]);
			/*-----------------------*/
				
        });
    }
    RED.nodes.registerType("weekSUN",weekSUNNode);
}
